# React Todo List

I have made this project to learn React by building applications.

Not accepting any PRs, as of now.

Deployed at: [https://react-todo-listt.netlify.app/](https://react-todo-listt.netlify.app/)

Feel free to create an issue regarding any suggestion/anti-patterns.
